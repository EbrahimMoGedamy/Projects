# swift-blurred-background-modal-view


The implementation of a blurred background, semi-transparent modal view written in Swift 3.

![](demo/demo.gif?raw=true)




Cheers!

**-Mohau**

mohau[AT]openbeacon[DOT]biz
